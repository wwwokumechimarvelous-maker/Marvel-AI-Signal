"""MARVEL AI - evidence-based IQ Option OTC signal scanner.

Uses read-only OTCharts candle data. It never logs into IQ Option or places orders.
No random/fallback signals are generated when data is missing.
"""
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.utils import get_color_from_hex
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.popup import Popup
from kivy.uix.progressbar import ProgressBar
from datetime import datetime, timezone, timedelta
from threading import Thread
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import json, os, math, time

BG = '#0A1629'; GOLD = '#FFD700'; MUTED = '#91A2B7'; GREEN = '#00C982'; RED = '#F04462'
API_BASE = 'https://otcharts.com/v1/candles'
PAIRS = ['EURUSD-OTC', 'GBPUSD-OTC', 'USDJPY-OTC', 'ETHUSD-OTC', 'AUDUSD-OTC']


def ema(values, period):
    if len(values) < period: return None
    alpha = 2.0 / (period + 1)
    out = sum(values[:period]) / period
    for v in values[period:]: out = alpha * v + (1-alpha) * out
    return out


def rsi(values, period=14):
    if len(values) <= period: return None
    changes = [values[i] - values[i-1] for i in range(1, len(values))]
    gains = sum(max(x, 0) for x in changes[:period]) / period
    losses = sum(max(-x, 0) for x in changes[:period]) / period
    for x in changes[period:]:
        gains = (gains*(period-1) + max(x, 0)) / period
        losses = (losses*(period-1) + max(-x, 0)) / period
    if losses == 0: return 100.0
    return 100 - (100 / (1 + gains/losses))


def analyse(candles):
    if len(candles) < 60: return None, 'Not enough candle history (need at least 60).'
    closes = [float(c['close']) for c in candles]
    highs = [float(c['high']) for c in candles]
    lows = [float(c['low']) for c in candles]
    e9, e21, e50 = ema(closes, 9), ema(closes, 21), ema(closes, 50)
    rv = rsi(closes)
    if None in (e9, e21, e50, rv): return None, 'Indicator calculation incomplete.'
    last, prev = candles[-1], candles[-2]
    body = closes[-1] - float(last['open'])
    candle_range = max(highs[-1] - lows[-1], 1e-12)
    body_ratio = abs(body) / candle_range
    recent = closes[-1] - closes[-6]
    scores = {'BUY': 0, 'SELL': 0}
    if e9 > e21: scores['BUY'] += 25
    elif e9 < e21: scores['SELL'] += 25
    if e21 > e50: scores['BUY'] += 20
    elif e21 < e50: scores['SELL'] += 20
    if recent > 0: scores['BUY'] += 15
    elif recent < 0: scores['SELL'] += 15
    if body > 0 and body_ratio >= .45: scores['BUY'] += 20
    elif body < 0 and body_ratio >= .45: scores['SELL'] += 20
    # RSI is used as a momentum filter, not as a standalone trigger.
    if 50 < rv < 68: scores['BUY'] += 20
    elif 32 < rv < 50: scores['SELL'] += 20
    direction = max(scores, key=scores.get)
    score = scores[direction]
    # Avoid chasing stretched readings and weak/contradictory conditions.
    if (direction == 'BUY' and rv >= 70) or (direction == 'SELL' and rv <= 30):
        return None, f'Conditions are stretched (RSI {rv:.1f}); setup filtered.'
    if score < 80:
        return None, f'No high-quality setup yet. Best setup score: {score}/100.'
    return {'direction': direction, 'score': score, 'rsi': rv,
            'ema9': e9, 'ema21': e21, 'ema50': e50,
            'momentum': 'Bullish' if direction == 'BUY' else 'Bearish'}, 'Setup passed the rule checks.'


class MarvelApp(App):
    def build(self):
        Window.clearcolor = get_color_from_hex(BG)
        self.title = 'MARVEL AI'
        self.key_path = os.path.join(self.user_data_dir, 'api_key.txt')
        self.api_key = self.load_key()
        self.pair = PAIRS[0]
        self.busy = False
        self.signal = None
        root = BoxLayout(orientation='vertical', padding=12, spacing=7)
        header = BoxLayout(size_hint_y=None, height=42)
        header.add_widget(Label(text='[b][color=FFD700]👑 MARVEL AI[/color][/b]', markup=True, font_size='22sp', halign='left'))
        self.connection = Label(text='[color=FFB84D]DATA NOT CONNECTED[/color]', markup=True, font_size='10sp')
        header.add_widget(self.connection); root.add_widget(header)
        root.add_widget(Label(text='[color=91A2B7]OTC MARKET INTELLIGENCE · READ-ONLY[/color]', markup=True, font_size='10sp', size_hint_y=None, height=20))
        self.pair_btn = Button(text='ASSET: EUR/USD OTC  ▾', size_hint_y=None, height=42, background_color=get_color_from_hex('#172B45'))
        self.pair_btn.bind(on_press=self.choose_pair); root.add_widget(self.pair_btn)
        self.signal_label = Label(text='[b][color=FFD700]READY TO SCAN[/color][/b]', markup=True, font_size='24sp', size_hint_y=None, height=65)
        root.add_widget(self.signal_label)
        self.score_label = Label(text='Setup score: —', color=get_color_from_hex(MUTED), size_hint_y=None, height=24)
        root.add_widget(self.score_label)
        self.bar = ProgressBar(max=100, value=0, size_hint_y=None, height=10); root.add_widget(self.bar)
        panel = GridLayout(cols=2, spacing=5, size_hint_y=None, height=125)
        self.rsi_label = self.metric('RSI (14)', '—'); self.trend_label = self.metric('TREND', '—')
        self.momentum_label = self.metric('MOMENTUM', '—'); self.data_label = self.metric('DATA AGE', '—')
        for w in [self.rsi_label, self.trend_label, self.momentum_label, self.data_label]: panel.add_widget(w)
        root.add_widget(panel)
        self.entry_label = Label(text='Entry time: —', color=get_color_from_hex(MUTED), size_hint_y=None, height=22); root.add_widget(self.entry_label)
        root.add_widget(Label(text='[b][color=FFD700]TRADE PLAN[/color][/b]', markup=True, size_hint_y=None, height=24))
        self.plan = Label(text='2-minute expiry  |  L1 +2m  ·  L2 +4m  ·  L3 +6m\nRecovery levels are conditional, never automatic', color=get_color_from_hex(MUTED), font_size='10sp', size_hint_y=None, height=42)
        root.add_widget(self.plan)
        self.status = Label(text='Add a data API key to begin.', color=get_color_from_hex(MUTED), font_size='11sp', size_hint_y=None, height=42)
        root.add_widget(self.status)
        scan = Button(text='[b]SCAN MARKET[/b]', markup=True, size_hint_y=None, height=52, background_color=get_color_from_hex(GOLD), color=get_color_from_hex(BG))
        scan.bind(on_press=self.scan); root.add_widget(scan)
        controls = BoxLayout(size_hint_y=None, height=40, spacing=6)
        keybtn = Button(text='API KEY / SETTINGS', background_color=get_color_from_hex('#263B56')); keybtn.bind(on_press=self.key_popup)
        controls.add_widget(keybtn)
        self.countdown_label = Label(text='NEXT REVIEW: MANUAL', color=get_color_from_hex(MUTED), font_size='10sp'); controls.add_widget(self.countdown_label)
        root.add_widget(controls)
        root.add_widget(Label(text='[color=91A2B7]Signals are analytical outputs, not guarantees. Verify price and expiry on IQ Option.[/color]', markup=True, font_size='9sp', size_hint_y=None, height=30))
        return root

    def metric(self, name, value):
        return Label(text=f'[color=91A2B7]{name}[/color]\n[b]{value}[/b]', markup=True, font_size='12sp')

    def load_key(self):
        try:
            with open(self.key_path, 'r') as f: return f.read().strip()
        except OSError: return ''

    def key_popup(self, *_):
        box = BoxLayout(orientation='vertical', padding=10, spacing=8)
        field = TextInput(text=self.api_key, hint_text='Paste your OTCharts API key', password=True, multiline=False, size_hint_y=None, height=45)
        box.add_widget(Label(text='Use an OTCharts key, NOT your IQ Option password.', size_hint_y=None, height=35))
        box.add_widget(field)
        save = Button(text='SAVE KEY', size_hint_y=None, height=45)
        popup = Popup(title='Market data connection', content=box, size_hint=(.92, .42))
        def do_save(*_):
            self.api_key = field.text.strip()
            os.makedirs(self.user_data_dir, exist_ok=True)
            with open(self.key_path, 'w') as f: f.write(self.api_key)
            popup.dismiss()
            self.status.text = 'API key saved on this device. Tap SCAN MARKET to test.'
        save.bind(on_press=do_save); box.add_widget(save); popup.open()

    def choose_pair(self, *_):
        box = BoxLayout(orientation='vertical', padding=8, spacing=5)
        popup = Popup(title='Choose OTC asset', content=box, size_hint=(.85, .7))
        for p in PAIRS:
            b = Button(text=p, size_hint_y=None, height=42)
            b.bind(on_press=lambda inst, pair=p: self.set_pair(pair, popup)); box.add_widget(b)
        popup.open()

    def set_pair(self, pair, popup):
        self.pair = pair; self.pair_btn.text = 'ASSET: ' + pair.replace('USD','/USD').replace('JPY','/JPY') + '  ▾'; popup.dismiss()
        self.status.text = 'Asset selected. Scan when ready.'

    def scan(self, *_):
        if self.busy: return
        if not self.api_key:
            self.status.text = 'Add your OTCharts API key in API KEY / SETTINGS.'; self.key_popup(); return
        self.busy = True; self.status.text = 'Requesting latest IQ Option OTC candles…'
        Thread(target=self.fetch_and_analyse, daemon=True).start()

    def fetch_and_analyse(self):
        try:
            url = f'{API_BASE}?venue=iq&symbol={self.pair}&tf=60&limit=100'
            req = Request(url, headers={'Authorization': 'Bearer ' + self.api_key, 'Accept': 'application/json', 'User-Agent': 'MarvelAI/1.1'})
            with urlopen(req, timeout=18) as response:
                payload = json.loads(response.read().decode('utf-8'))
            candles = payload.get('candles', [])
            if len(candles) < 60: raise ValueError(f'Only {len(candles)} candles received; at least 60 are required.')
            # The provider timestamps candles in Unix seconds.
            latest = int(candles[-1].get('time', 0))
            age = max(0, int(time.time()) - latest)
            if age > 150: raise ValueError(f'Data is stale ({age}s old). No signal released.')
            result, note = analyse(candles)
            Clock.schedule_once(lambda dt: self.show_result(result, note, age), 0)
        except HTTPError as e:
            message = 'API key rejected or access limit reached.' if e.code in (401,403,429) else f'Data service returned HTTP {e.code}.'
            Clock.schedule_once(lambda dt, m=message: self.fail(m), 0)
        except (URLError, TimeoutError) as e:
            Clock.schedule_once(lambda dt: self.fail('Connection problem. Check internet and try again.'), 0)
        except Exception as e:
            msg = str(e)[:150]
            Clock.schedule_once(lambda dt, m=msg: self.fail(m), 0)

    def show_result(self, result, note, age):
        self.busy = False; self.connection.text = '[color=00C982]DATA CONNECTED[/color]'
        self.data_label.text = f'[color=91A2B7]DATA AGE[/color]\n[b]{age}s[/b]'
        self.entry_label.text = 'Checked: ' + datetime.now(timezone(timedelta(hours=1))).strftime('%I:%M:%S %p WAT')
        if not result:
            self.signal = None; self.signal_label.text = '[b][color=FFD700]SCANNING MARKET[/color][/b]'
            self.score_label.text = 'No qualifying BUY/SELL setup'; self.bar.value = 0
            self.status.text = note; self.rsi_label.text = '[color=91A2B7]RSI (14)[/color]\n[b]—[/b]'
            self.trend_label.text = '[color=91A2B7]TREND[/color]\n[b]—[/b]'; self.momentum_label.text = '[color=91A2B7]MOMENTUM[/color]\n[b]—[/b]'
            return
        self.signal = result; direction = result['direction']; col = GREEN if direction == 'BUY' else RED
        self.signal_label.text = f'[b][color={col}]{direction}[/color][/b]'
        self.score_label.text = f"Evidence score: {result['score']}/100 · not a win probability"
        self.bar.value = result['score']; self.rsi_label.text = f"[color=91A2B7]RSI (14)[/color]\n[b]{result['rsi']:.1f}[/b]"
        self.trend_label.text = f"[color=91A2B7]TREND[/color]\n[b]{'UP' if direction == 'BUY' else 'DOWN'}[/b]"
        self.momentum_label.text = f"[color=91A2B7]MOMENTUM[/color]\n[b]{result['momentum']}[/b]"
        self.status.text = note + ' Confirm the live quote and candle timing in IQ Option.'

    def fail(self, message):
        self.busy = False; self.connection.text = '[color=FFB84D]DATA ISSUE[/color]'
        self.signal = None; self.signal_label.text = '[b][color=FFD700]SCAN UNAVAILABLE[/color][/b]'
        self.score_label.text = 'No signal generated'; self.bar.value = 0; self.status.text = message


if __name__ == '__main__':
    MarvelApp().run()
