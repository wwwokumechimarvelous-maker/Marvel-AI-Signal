MARVEL AI v1.1 - IQ OPTION OTC SCANNER

WHAT CHANGED
- Removed random BUY/SELL and random confidence values.
- Added read-only OTCharts IQ Option OTC candle-data connection.
- Added local API-key settings (store an OTCharts key only; never enter IQ Option credentials).
- Added EMA 9/21/50, RSI(14), momentum and candle-body checks.
- Signals are released only when the rule-based evidence score reaches the threshold.
- Stale/missing data and API errors do not create signals.
- The app does not log in to IQ Option and cannot place trades.

FREE DATA LIMITATION (CHECKED 23 NOV 2026)
The OTCharts API reference currently says its free tier provides 200 requests in the first month and NO live streaming. Live streams and payout percentages require a paid plan. Therefore this build supports manual candle scans on the free tier; it is not continuous live streaming. Check the provider's current plan terms before creating an account or key.

SETUP
1. Create an account and API key at https://otcharts.com (independent provider, not IQ Option).
2. Open MARVEL AI, tap API KEY / SETTINGS, and paste the OTCharts key.
3. Select an available OTC pair and tap SCAN MARKET.
4. Never paste your IQ Option password or session/SSID into this app.

BUILD APK
Build with Buildozer on Linux/Google Colab:
  pip install buildozer
  buildozer android debug
APK output: bin/ directory.

IMPORTANT
A setup score is not a probability of winning. A two-minute direction forecast is uncertain; test on a practice account and record results before risking money. Recovery/martingale staking can rapidly increase losses and is not automated by this app.
