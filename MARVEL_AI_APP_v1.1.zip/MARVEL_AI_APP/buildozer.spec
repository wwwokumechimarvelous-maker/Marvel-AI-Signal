[app]
title = MARVEL AI
package.name = marvelai
package.domain = com.marvel.ai
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,txt
version = 1.1
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.permissions = INTERNET
android.api = 33
android.minapi = 21

[buildozer]
log_level = 2
